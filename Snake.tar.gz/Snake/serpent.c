#include <stdlib.h>
#include <stdio.h>
#include <SDL.h>
#include <SDL_image.h>
#include <serpent.h>


/**  fonction qui initialises la fenetre du jeu 
 */

void affichage (Data* data){
  int i;
  data->taille = 1; //! Initialisation de la taille du serpent, il y aura la tete et 1 corps.
  SDL_WM_SetCaption("Snake", NULL); //! Affiche le mots "Snake" en haut de la fenetre.
  data->ecran = SDL_SetVideoMode(19*TE, 14*TE, 32, SDL_ANYFORMAT); //! Definit la taille de la fenetre, on peut afficher 19 fois la taille d'une image en x, et 14 fois en y. 




  data->img_snake[0] = IMG_Load("./Image/tete.png"); //! IMG_Load est d�finie par SDL pour t�l�charger une image ici de la tete.
  data->snake[0].x = 5;  //! Definit la positon initiale sur x de la tete. 
  data->snake[0].y = 3;  //! Definit la positon initiale sur y de la tete. 
  data->snake[1].x = 4;  //! Definit la positon initiale sur x du premier corps. 
  data->snake[1].y = 3; //! Definit la positon initiale sur y du premier corps. 
  data->img_snake[1] = IMG_Load("./Image/cor.png"); //! Telecharge l'image du premier corps.
  

 for(i = 0; i>data->taille ; i++){   //! boucle qui rajoute un corp � chaque fois que la taille du serpent augmente.
  data->img_snake[i] = IMG_Load("./cor.png");
 } 

 //!Affiche les differentes orientation de la tete. 
  data->dir[HAUT] = IMG_Load("./Image/tete.png");
  data->dir[BAS] = IMG_Load("./Image/tetesouth.png");
  data->dir[GAUCHE] = IMG_Load("./Image/tetewest.png");
  data->dir[DROITE] = IMG_Load("./Image/teteest.png");


  //!Affichage de la pomme a une position aleatoire tout en respectant la dimension de la fenetre.
  data->pomme = IMG_Load ("./Image/pomme.png");
  data->pom.x = rand() % 17;
  data->pom.y = rand() % 12;

  //! Telecharge image perdu quand on perd et image gagne quand on gagne.
  data->perdu = IMG_Load("./Image/perdu.png");
  data->gagne = IMG_Load("./Image/gagne.jpg");
}



/**  fonction quand on perd.
 * On perd lorsque le serpent se touche ou bien touche le bord de la fenetre.
 */
void perdu (Data* data) {
  int i;
  SDL_Rect position; //! fonction definit par SDL qui definit la position souhaitee lors de l'affichage de l'image(pour SDL_BlitSurface).
  position.x = 0; //! Ici nous avons mis 0 car on souhaite afficher l'image en plein ecran.
  position.y = 0;
  //! Quand il se touche 
  for(i = 1; i<=data->taille ;i++){ //! Boucle qui parcourt le serpent.
    if (data->snake[0].x == data->snake[i].x && data->snake[0].y == data->snake[i].y) //! Si la position de la tete est la meme que celle d'une partie du corps.
      SDL_BlitSurface (data->perdu, NULL, data->ecran, &position);} //! fonction definit par SDL qui affiche l'image de perdu.
  //! Quand il touche les bords
  if(   (data->snake[0].x > 19 || data->snake[0].x < 0 || data->snake[0].y < 0 || data->snake[0].y > 13) ) {//! Si la position de la tete touche les bords de la fenetre.
    SDL_BlitSurface (data->perdu, NULL, data->ecran, &position);//! fonction definit par SDL qui affiche l'image de perdu.

  }
}
 


/**  fonction quand on gagne.
 * On gagne lorsque le serpent mange toutes les pommes.
 */
void gagne(Data* data){
  SDL_Rect position; //! fonction definit par SDL qui definit la position souhaitee lors de l'affichage de l'image(pour SDL_BlitSurface).
  position.x = 0; //! Ici nous avons mis 0 car on souhaite afficher l'image en plein ecran.
  position.y = 0;
  if(data->compte == 10) { //! Compte les pommes. Si 10 pommes sont mangees
    affichage(data); //! retourne a la fenetre du debut de jeu.
       SDL_BlitSurface (data->gagne, NULL, data->ecran, &position);  //! fonction definit par SDL qui affiche l'image de gagner.
  }
}



/** fonction qui dessine une pomme en utilisant des fonctions definit par SDL 
 */
void dessinePomme(Data* data, Pomme* s, SDL_Surface * surface) {
  SDL_Rect position;
  position.x = s->x * TE; //! la position de la pomme (qui est definit dans la fontion affichage) qui tient compte de la taille de l'image afin que l'image du serpent ne se confonde pas avec celle de la pomme.
  position.y = s->y * TE;
  SDL_BlitSurface (surface, NULL, data->ecran, &position);
}


/** fonction qui dessine le serpent en utilisant des fonctions definit par SDL
 *  le compteur permet que lorsque on affiche un autre corps il prend on compte la postion d'avant pour afficher l'image a la suite
 */
void dessineSerpent(Data* data, Snake* s, SDL_Surface * surface) {
  SDL_Rect position;
  if(s->compteur >= 0) {
    position.x = s->x * TE - s->compteur * direction[s->dir].x;
    position.y = s->y * TE - s->compteur * direction[s->dir].y;
     s->compteur--;} 
  else {
    position.x = s->x * TE;
    position.y = s->y * TE;}
  SDL_BlitSurface (surface, NULL, data->ecran, &position);
}





/** Fonction qui permet au snake de se deplacer.
 * Au debut x et y  valent la position de la tete avec la direction choisie (voir .h)
 * Le serpent bouge seulement si la tete du serpent est differente de sa position precedente.
 * On decalare une variable m pour y stocker la taille du serpent.
 * data->taille + 1: On ajoute 1 pour ne pas comptabiliser la tete.
 * La tete avance puis le corps 1 prend sa position, puis le corps 2 prend la position du corps 1... 
 * On reinitialise la tete � x et y pour qu'elle ne soit pas pietinee par le corps */

void bouge(Data* data,Snake s[],int dir){
  int m;
  int x,y;
  x = s[0].x + direction[dir].x;
  y = s[0].y + direction[dir].y;
  if(x != s[1].x  ||  y != s[1].y){
    for(m = data->taille + 1; m > 0  ;m--){
      s[m].x = s[m-1].x;
      s[m].y = s[m-1].y;
    }    
    s[0].x = x;
    s[0].y = y;    
  }
}




/** C'est la boucle de jeu qui permet au jeu de continuer a tourner 
 * gere les evenements avec les touches du clavier
 * Pour chaque touche directionnel on affiche l'image correspondant a la direction puis on appelle la fonction bouge qui fera 
 * deplacer le serpent
 */

void boucleDeJeu(Data* data){
  int i;
  affichage(data); //! On appelle la fonction affichage qui affichera la fenetre avec les images
  int continuer = 1; 
  SDL_Event event;
  while (continuer) //! Boucle qui permettra � la fenetre SDL de s'afficher tant que continuer est different de 0.
    {
      SDL_WaitEvent(&event);
      switch(event.type){	 
      case SDL_QUIT: //! La fenetre se ferme lorsqu'on quitte la fenetre (avec la croix en haut a gauche) car continuer vaudra 0
	continuer = 0;
	break;
      case SDL_KEYDOWN:
	switch(event.key.keysym.sym)
	  {
	  case SDLK_UP: 
	    data->img_snake[0] = data->dir[HAUT];
	    bouge(data,&data->snake[0],HAUT);
	    break;
	    
	  case SDLK_DOWN:
	    data->img_snake[0] = data->dir[BAS];
	    bouge(data,&data->snake[0],BAS); 
	    break;
	    
	  case SDLK_RIGHT:
	    data->img_snake[0] = data->dir[DROITE];
	    bouge(data,&data->snake[0],DROITE); 
	    break;
	    
	  case SDLK_LEFT:
	    data->img_snake[0] = data->dir[GAUCHE];
	    bouge(data,&data->snake[0],GAUCHE);
	    break;
	    
	  default:break;
	  }  
      }
      

      SDL_FillRect(data->ecran, NULL, SDL_MapRGB(data->ecran->format, 0, 147, 0)); //! fonction definit par SDL qui permet de choisir un fond a la fenetre, nous avons choisi un fond vert.
  
      dessineSerpent(data, &data->snake[0],data->img_snake[0]); //! Dessine un corps.
  
      for(i = 1; i<=data->taille ;i++){     //! Dessine un corps a chaque fois que la taille augmente.
	dessineSerpent(data, &data->snake[i],data->img_snake[1]); 
      }
      
      dessinePomme(data, &data->pom, data->pomme); //! Dessine une pomme.

      //! Si la position de la tete du serpent = la position de la pomme.
      //! Effacer la pomme.
      //! La taille du serpent augmente de 1.
      //! Le compteur de pomme augmente de 1.
      //! Affiche une pomme � une position aleatoire sans depasser la taille de la fenetre.
      
      if(data->snake[0].x == data->pom.x && data->snake[0].y == data->pom.y){ 
	data->pomme = 0; 
	data->taille++; 
	data->compte++; 
	data->pomme = IMG_Load ("./Image/pomme.png");
	data->pom.x = rand() % 17; 
	data->pom.y = rand() % 12;
      }

      perdu(data);
      gagne(data);
      SDL_Flip(data->ecran); //! fonction definit par SDL qui met a jour l'ecran.  
    }  
    
}






int main(int argc, char *argv[]){
  Data* data = malloc(sizeof *data);
  SDL_Init(SDL_INIT_VIDEO); //! Initialise la SDL
  boucleDeJeu(data); //! appelle la fonction boucleDeJeu.
 
  return 0;
}
