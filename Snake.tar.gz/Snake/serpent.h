#ifndef _SERPENT_H

#define _SERPENT_H


#ifdef __cplusplus

extern "C" {
  
#endif


/**
 * Structure d'un point
 */
  
typedef struct{
  int x;
  int y;
}Point;

  /**
   * Strucure de la pomme
   * Elle définira la position de la pomme sur x et sur y
   */
  
typedef struct{
  int x;
  int y;
} Pomme;

  
  /**
   * Strucure du serpent 
   * Elle définira la position du serpent sur x et sur y
   * Elle compte également un compteur (voir .c)
   */
typedef struct{
  int x;
  int y;
  int compteur;
  int dir;
} Snake;
  
  
typedef struct{
  SDL_Surface *ecran;/**< \ la fenetre du jeu */
  SDL_Surface *img_snake[19*14];/**< image du serpent avec la taille maximale qui correspond à la fenetre */
  SDL_Surface *dir[4];/**< tableau de 4 directions  */
  SDL_Surface *pomme;/**< Declaration de la surface pomme */
  SDL_Surface* perdu;/**< Declaration de la surface perdu */
  SDL_Surface* gagne;/**< Declaration de la surface gagné */
  Snake snake[19 *14];/**< Declaration du serpent etant de type Snake */
  Pomme pom;/**< declaration de la fonction pom de type Pomme */
  int direction;
  int taille; /**< taille du serpent, la taille ne concerne que le corps du serpent si elle est egale à 1, à l'affichage il n'y aura qu'un corps.*/

  int compte; /**< compteur de pomme */
}Data;

  enum{TE = 34}; /**<taille de l'image en pixel (pomme et serpent ont la meme taille)*/
  
enum{HAUT, BAS, DROITE, GAUCHE, NBD };
Point direction[NBD] =  { {0, -1}, {0, 1}, {1, 0}, {-1, 0}}; 







#ifdef __cplusplus
}

#endif

#endif
