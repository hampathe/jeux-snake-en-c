var searchData=
[
  ['nbd',['NBD',['../serpent_8h.html#adf764cbdea00d65edcd07bb9953ad2b7afbd82aaa29f984ca5b2ddaf182a7f668',1,'serpent.h']]]
];
