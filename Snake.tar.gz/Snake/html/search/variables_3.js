var searchData=
[
  ['gagne',['gagne',['../structData.html#a52dca6b4b30b0bc35c78594a9fd49c87',1,'Data']]]
];
