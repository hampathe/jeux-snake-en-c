var searchData=
[
  ['sdl_5fblitsurface',['SDL_BlitSurface',['../serpent_8c.html#a8a2bf05fea473f20254ef85eb6032142',1,'serpent.c']]]
];
