var searchData=
[
  ['serpent_2ec',['serpent.c',['../serpent_8c.html',1,'']]],
  ['serpent_2eh',['serpent.h',['../serpent_8h.html',1,'']]],
  ['snake',['Snake',['../structSnake.html',1,'Snake'],['../structData.html#a9c38d79884368510e49870e48a44ee19',1,'Data::snake()']]]
];
