var searchData=
[
  ['gagne',['gagne',['../structData.html#a52dca6b4b30b0bc35c78594a9fd49c87',1,'Data::gagne()'],['../serpent_8c.html#a69051e538a5cf521d8dd3d1453b89511',1,'gagne():&#160;serpent.c']]],
  ['gauche',['GAUCHE',['../serpent_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a4ee960d97b04a1f22ed7ff81c7aa2e86',1,'serpent.h']]]
];
