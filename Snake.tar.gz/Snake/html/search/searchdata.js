var indexSectionsWithContent =
{
  0: "abcdeghimnpstxy",
  1: "dps",
  2: "s",
  3: "abdgmp",
  4: "cdegipstxy",
  5: "bdghnt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Valeurs énumérées"
};

