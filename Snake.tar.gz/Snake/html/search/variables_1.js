var searchData=
[
  ['dir',['dir',['../structSnake.html#aecc3f67c7c47b26bdfbdb93a2cf8819f',1,'Snake::dir()'],['../structData.html#a13bb714a92cdbb2d4e6628f44e5d80cf',1,'Data::dir()']]],
  ['direction',['direction',['../structData.html#a122782fce2c4797549b714755d4b8b3e',1,'Data::direction()'],['../serpent_8h.html#aa62a0b4a350f94760090894022883ca0',1,'direction():&#160;serpent.h']]]
];
