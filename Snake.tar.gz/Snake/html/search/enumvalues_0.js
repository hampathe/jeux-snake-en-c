var searchData=
[
  ['bas',['BAS',['../serpent_8h.html#adf764cbdea00d65edcd07bb9953ad2b7a4b07baad9e862178efeac3e522475caa',1,'serpent.h']]]
];
