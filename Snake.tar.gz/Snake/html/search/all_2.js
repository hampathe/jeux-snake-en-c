var searchData=
[
  ['compte',['compte',['../structData.html#a4374c9b2a1ead1e0360256a14a3f132c',1,'Data']]],
  ['compteur',['compteur',['../structSnake.html#a0f6e09ad815f1b07dad3783b9c7759e2',1,'Snake']]]
];
